<template>
    <div class="waiting-page">
      <h1>Order in Progress</h1>
      <p>Your order is being processed. Please wait...</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'WaitingPage'
  };



  </script>
  
  <style>
  .waiting-page {
    text-align: center;
    margin-top: 50px;
  }
  </style>